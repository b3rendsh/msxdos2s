#!/bin/sh
export LD_LIBRARY_PATH=`pwd`/lib
export QT_QPA_PLATFORM=xcb
./JIOServer
