MSXDOS disk image with:
1. 16MB system partition
2. 100MB FAT16 partition